<?php

namespace frontend\models;

use common\models\UserFav;
use Yii;
use yii\base\Model;
use yii\helpers\Json;

/**
 * ContactForm is the model behind the contact form.
 */
class CalcForm extends Model
{
    public $region_id;
    public $person_type_id;
    public $house_type_id;
    public $square;
//    public $calc_result;
    public $profit;

    public $num_pers;
    public $num_pens;
    public $num_children;

    public $discount;
    public $spend;
    public $overhaul;



    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['person_type_id', 'house_type_id', 'square', 'region_id'], 'required'],
            [['person_type_id', 'house_type_id', 'region_id'], 'integer'],
            [['person_type_id', 'house_type_id', 'region_id',
                'num_pers', 'num_pens', 'num_children'], 'filter', 'filter' => 'intval'],
            [['square', 'profit', 'discount', 'spend'], 'number'],
            [['square', 'profit', 'discount', 'spend'], 'filter', 'filter' => 'floatval'],

            [['num_pers', 'num_pens', 'num_children'], 'integer'],

            [['overhaul'], 'boolean'],
            [['overhaul'], 'filter', 'filter' => 'boolval'],

        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'region_id' => 'Муниципальное образование',
            'person_type_id' => 'К какой категории граждан вы относитесь?',
            'house_type_id' => 'Тип жилья',
            'square' => 'Площадь жилья',
            'num_pers' => 'Кол-во взрослых',
            'num_pens' => 'Кол-во пенсионеров',
            'num_children' => 'Кол-во детей',
            'profit' => 'Общий доход семьи (руб. в мес.)',

            'discount' => 'Предоставленная скидка',
            'spend' => 'Квартплата на данный момент',
            'overhaul' => 'Взнос за капремонт',
        ];
    }

    public function loadFromProfile()
    {
        $this->region_id = 4;
        $this->person_type_id = 1;
        $this->house_type_id = 1;
        $this->square = 16.2;
        $this->num_pers = 1;
        $this->num_pens = 2;
        $this->num_children = 3;
        $this->profit = 6500;
        $this->discount = 1200;
        $this->spend = 8300;
        $this->overhaul = true;
    }

    public function calc()
    {
        $data = $this->toJson();
        $data['type'] = 'SetOfParams';
        $json = Json::encode($data);

        $result = \Yii::$app->db->createCommand("select public.workwithparams(:json) as result")
            ->bindValue(':json', $json)
            ->queryOne();

        $result = Json::decode($result['result']);

        return $result;
    }


    public function saveToFav()
    {
        $user = Yii::$app->user;
        $fav = new UserFav([
            'user_id' => $user->id,
            'data' => $this->toJson()
        ]);
        $fav->save(false);
    }

    /**
     * @return string
     */
    public function toJson()
    {
        return $this->getAttributes([
            'region_id',
            'person_type_id',
            'house_type_id',
            'square',
            'num_pers',
            'num_pens',
            'num_children',
            'profit',
            'discount',
            'spend',
            'overhaul',
        ]);
    }

    public function fromJson($data)
    {
        $this->setAttributes($data);
    }




}
