<?php
namespace frontend\controllers;

use common\models\HouseType;
use common\models\PersonType;
use common\models\Region;
use common\models\UserFav;
use frontend\models\CalcForm;
use Yii;
use yii\helpers\ArrayHelper;
use yii\web\Controller;

class CalcController extends Controller
{
    public function actionIndex($fav_id = null)
    {
        $regions = ArrayHelper::map(Region::find()->where(['ismo' => true])->asArray()->all(), 'id', 'name');
        $personTypes = ArrayHelper::map(PersonType::find()->asArray()->all(), 'id', 'name');
        $houseTypes = ArrayHelper::map(HouseType::find()->asArray()->all(), 'id', 'name');
        $user = Yii::$app->user;


        $model = new CalcForm();
        $result = null;

        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            switch (\Yii::$app->request->post('submit1')) {
                case 'calc':
                    $result = $model->calc();
                    break;

                case 'save':
                    $model->saveToFav();
                    break;
            }

        } else {
            if ($fav_id) {
                $model = $this->loadModelFromFav($fav_id);
                if (!$model) {
                    return $this->redirect('index');
                }
            } else {
                if (!$user->isGuest) {
                    $model->loadFromProfile();
                }

            }

        }

        return $this->render('index', [
            'model' => $model,
            'regions' => $regions,
            'personTypes' => $personTypes,
            'houseTypes' => $houseTypes,
            'result' => $result,
        ]);
    }

    public function loadModelFromFav($fav_id)
    {
        $user = Yii::$app->user;
        $fav = UserFav::find()->where(['user_id' => $user->id, 'id' => $fav_id])->one();
        if (!$fav) {
            return null;
        }
        
        $model = new CalcForm();
        $model->fromJson($fav['data']);
        return $model;
    }

    public function actionFavList()
    {
        $user = Yii::$app->user;

        if (Yii::$app->user->isGuest) {
            $userFav = [];
        } else {
            $userFav = UserFav::find()->where(['user_id' => Yii::$app->user->id])->all();
        }

        return $this->render('fav-list', [
            'userFav' => $userFav,
        ]);

    }

    public function actionLgotList()
    {
        return $this->redirect('index');
    }
}