<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use frontend\assets\AppAsset;
use common\widgets\Alert;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body>
<?php $this->beginBody() ?>

<div class="wrap">
    <?php
    NavBar::begin([
        'brandLabel' => Html::img('/images/logo.png').' <span class="brand-title">Единый калькулятор предварительного расчета размера социальных выплат</span>',
        'brandUrl' => Yii::$app->homeUrl,
        'options' => [
            'class' => 'navbar-inverse navbar-fixed-top navbar-calc',
        ],
    ]);
    $menuItems = [
//        ['label' => 'Главная', 'url' => ['/site/index']],
        ['label' => 'Рассчитать льготу', 'url' => ['/calc/index']],
        ['label' => 'Сохраненные расчеты', 'url' => ['/calc/fav-list']],
        ['label' => 'Узнать о доступных льготах', 'url' => ['/calc/lgot-list']],
//        ['label' => 'Contact', 'url' => ['/site/contact']],
    ];
    if (Yii::$app->user->isGuest) {
//        $menuItems[] = ['label' => 'Signup', 'url' => ['/site/signup']];
        $menuItems[] = ['label' => 'Вход', 'url' => ['/site/login']];
    } else {
        $menuItems[] = '<li>'
            . Html::beginForm(['/site/logout'], 'post')
            . Html::submitButton(
//                'Выход (' . Yii::$app->user->identity->username . ')',
                'Выход',
                ['class' => 'btn btn-link logout']
            )
            . Html::endForm()
            . '</li>';
    }
    echo Nav::widget([
        'options' => ['class' => 'navbar-nav navbar-right'],
        'items' => $menuItems,
    ]);
    NavBar::end();
    ?>

    <div class="container">
        <!--
        <?= Breadcrumbs::widget([
            'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
        ]) ?>
        -->
        <?= Alert::widget() ?>
        <?= $content ?>
    </div>
</div>

<footer class="footer footer-middle">
    <div class="container">
        <div class="row">
            <div class="col-xs-6">
                <ul class="footer-links">
                    <li><a href="#"><img src="/images/question-icon.png" alt=""> О получении социальных льгот</a></li>
                    <li><a href="#"><img src="/images/doc-icon.png" alt=""> Перечень документов</a></li>
                    <li><a href="#"><img src="/images/marker-icon.png" alt=""> Адреса ведомств</a></li>
                </ul>
            </div>
            <div class="col-xs-6">
                <div class="row">
                    <div class="col-xs-8">
                        <p>Вы также можете установить приложение Социальный калькулятор на свой смартфон</p>
                        <a href="#" class="store-button pull-left"><img src="/images/google-play-icon.png" alt=""> Google Play</a>
                        <a href="#" class="store-button pull-right"><img src="/images/apple-icon.png" alt=""> App Store</a>
                    </div>
                    <div class="col-xs-4">
                        <img src="/images/barcode.png" alt="" class="barcode">
                    </div>
                </div>
            </div>
        </div>


        <!-- <p class="pull-left">&copy; <?= Html::encode(Yii::$app->name) ?> <?= date('Y') ?></p> -->

        <!--<p class="pull-right"><?= Yii::powered() ?></p>-->
    </div>
</footer>

<footer class="footer footer-bottom">
    <div class="row ">
        <div class="col-xs-12">
            <p class="text-center"><img src="/images/logo-grey.png" alt=""> Единый калькулятор предварительного расчета размера социальных выплат, 2019 г.</p>
        </div>
    </div>
</footer>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
