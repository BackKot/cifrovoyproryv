<?php
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\bootstrap\Modal;

/* @var $this yii\web\View */
/* @var $model \frontend\models\CalcForm */
/* @var $regions [] */
/* @var $personTypes [] */
/* @var $houseTypes [] */
/* @var $userFav [] */
/* @var $result [] */

$this->title = 'Социальный калькулятор';
$isGuest = Yii::$app->user->isGuest;

$js = <<<JS
$(document).ready(function(){
    $('.btn-calc-result').click();
});
JS;


$this->registerJs($js, \yii\web\View::POS_READY);
?>
<div class="site-calc">
    <?php $form = ActiveForm::begin(); ?>

    <div class="row">
        <div class="col-xs-6">
            <?= $form->field($model, 'region_id')->widget(Select2::className(), [
                'data' => $regions,
                'options' => ['placeholder' => '--'],
                'pluginOptions' => [
                    'allowClear' => true
                ],
            ]) ?>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-6">
            <?= $form->field($model, 'person_type_id')->widget(Select2::className(), [
                'data' => $personTypes,
                'options' => ['placeholder' => '--'],
                'pluginOptions' => [
                    'allowClear' => true
                ],
            ]) ?>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-6">
            <?= $form->field($model, 'house_type_id')->widget(Select2::className(), [
                'data' => $houseTypes,
                'options' => ['placeholder' => '--'],
                'pluginOptions' => [
                    'allowClear' => true
                ],
            ]) ?>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-6">
            <?= $form->field($model, 'square')->textInput() ?>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-6">
            <div class="row">
                <div class="col-xs-4">
                    <?= $form->field($model, 'num_pers')->textInput() ?>
                </div>
                <div class="col-xs-4">
                    <?= $form->field($model, 'num_pens')->textInput() ?>
                </div>
                <div class="col-xs-4">
                    <?= $form->field($model, 'num_children')->textInput() ?>
                </div>
            </div>

        </div>
    </div>

    <div class="row">
        <div class="col-xs-6">
            <div class="row">
                <div class="col-xs-4">
                    <?= $form->field($model, 'profit')->textInput() ?>
                </div>
                <div class="col-xs-4">
                    <?= $form->field($model, 'discount')->textInput() ?>
                </div>
                <div class="col-xs-4">
                    <?= $form->field($model, 'spend')->textInput() ?>
                </div>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-6">
            <?= $form->field($model, 'overhaul')->checkbox() ?>
        </div>
    </div>

    <div class="form-group">
        <?= Html::submitButton(Yii::t('app', 'Рассчитать'), ['class' => 'btn btn-primary', 'name' => 'submit1', 'value' => 'calc']) ?>
    </div>

    <?php if (!$isGuest): ?>
    <div class="form-group">
        <?= Html::submitButton(Yii::t('app', 'Сохранить расчет'), ['class' => 'btn btn-info', 'name' => 'submit1', 'value' => 'save']) ?>
    </div>
    <?php endif; ?>

    <?php ActiveForm::end(); ?>


    <?php
    if ($result) {
        Modal::begin([
            'header' => '<h4>'.$result['message'].'</h4>',
            'toggleButton' => [
                'label' => '<i class="glyphicon glyphicon-plus"></i> Результат',
                'class' => 'btn btn-success btn-calc-result hidden'
            ],
            'footer' => '<button type="button" class="btn btn-default btn-info" data-dismiss="modal">OK</button>',
        ]);
        if (isset($result['value']) && ($result['value'] > 0))
        {
            echo 'Вам положена льгота в размере '.$result['value']. ' руб.';
        } else {
            echo  '<strong>Извините,</strong> но льгота вам не положена.  '.$result['message'];
        }

        Modal::end();
    }

    ?>
    <!--
    <?php if ($result): ?>
        <?php if (isset($result['value']) && ($result['value'] > 0)): ?>
            <div class="alert alert-info">
                <strong><?= $result['message'] ?></strong> Вам положена льгота в размере <?= $result['value'] ?> руб.
            </div>
            <?php else: ?>
            <div class="alert alert-warning">
                <strong>Извините,</strong> но льгота вам не положена. <?= $result['message'] ?>
            </div>
        <?php endif; ?>
        <?php /*var_dump($result);*/ ?>
    <?php endif; ?>
    -->
</div>
