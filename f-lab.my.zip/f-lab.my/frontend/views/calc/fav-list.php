<?php
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $userFav [] */


?>
<h4>Сохраненные расчеты</h4>
<ul>
    <?php foreach ($userFav as $fav): ?>
        <?php
        $fav_name = Yii::$app->formatter->asDatetime($fav['created_at']);
        ?>
        <li><?= Html::a($fav_name, ['index', 'fav_id' => $fav['id']]) ?></li>
    <?php endforeach; ?>
</ul>
