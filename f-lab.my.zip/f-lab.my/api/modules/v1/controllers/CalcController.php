<?php
namespace api\modules\v1\controllers;


use api\controllers\BaseApiController;
use frontend\models\CalcForm;
use mc\models\search\NotificationSearch;
use Yii;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;

class CalcController extends BaseApiController
{
    public function behaviors()
    {
        $behaviors = parent::behaviors();

        $behaviors = ArrayHelper::merge([
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'index'  => ['POST'],
                ],
            ]
        ], $behaviors);

        return $behaviors;
    }

    public function actionIndex()
    {
        $request = Yii::$app->request;
        $model = new CalcForm($request->post());
        $result = $model->calc();
        return $result;
//        $searchModel = new NotificationSearch();
//        $searchModel->onlyActive = true;
//        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
//
//        return $dataProvider;
    }
}