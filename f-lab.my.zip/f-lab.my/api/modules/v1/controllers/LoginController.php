<?php
namespace api\modules\v1\controllers;

use common\models\User;
use Yii;
use yii\base\Exception;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;

class LoginController extends \yii\rest\Controller
{

    public function behaviors()
    {
        $behaviors = parent::behaviors();

        $behaviors = ArrayHelper::merge([
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'login' => ['POST']
//                'index'  => ['GET'],
//                'view'   => ['GET'],
//                'create' => ['GET', 'POST'],
//                'update' => ['GET', 'PUT', 'POST'],
//                'delete' => ['POST', 'DELETE'],
                ],
            ]
        ], $behaviors);

        return $behaviors;
    }


    public function actionIndex()
    {
        $post = Yii::$app->request->getBodyParams();
        if (!isset($post['email'])) {
            throw new \Exception(Yii::t('app', 'Email не указан'));
        }

        if (!isset($post['password'])) {
            throw new \Exception(Yii::t('app', 'Пароль не указан'));
        }

        $user = User::findByUsername($post['email']);
        if (!$user) {
            throw new \Exception(Yii::t('app', 'Пользователь или пароль указаны не верно'));
        }

        if (!$user->validatePassword($post['password'])) {
            throw new \Exception(Yii::t('app', 'Пользователь или пароль указаны не верно'));
        }

        return [
            'access_token' => $user->access_token
        ];
    }
}