<?php
namespace api\modules\v1\controllers;


use api\controllers\BaseApiController;
use common\models\UserContract;
use common\models\UserFcm;
use frontend\models\CalcForm;
use Yii;
use yii\db\Exception;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;
use yii\web\NotFoundHttpException;

class UserController extends BaseApiController
{
    public function behaviors()
    {
        $behaviors = parent::behaviors();

        $behaviors = ArrayHelper::merge([
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'profile' => ['GET'],
                    'fcm'  => ['POST'],
                ],
            ]
        ], $behaviors);

        return $behaviors;
    }

    public function actionProfile()
    {
        $user = \Yii::$app->user->identity;
        $profile = $user->userProfile;

        return [
            'email' => $user['email'],
            'first_name' => $profile['first_name'] ?? null,
            'second_name' => $profile['second_name'] ?? null,
            'third_name' => $profile['third_name'] ?? null,
            'snils' => $profile['snils'] ?? null,
            'pasp_num' => $profile['pasp_num'] ?? null,
            'pasp_ser' => $profile['pasp_ser'] ?? null,
            'pasp_date' => $profile['pasp_date'] ?? null,
            'inn' => $profile['inn'] ?? null,
        ];
    }
    
    public function actionDefaultValues()
    {
        $model = new CalcForm();
        $model->loadFromProfile();

        return $model;
    }

    /**
     * Register FCM token
     * @return bool
     * @throws \yii\base\InvalidConfigException
     * @throws \Exception
     * @throws \Throwable
     */
//    public function actionFcm()
//    {
//        $user = \Yii::$app->user;
//        $request = Yii::$app->request;
//
//        $old_token = $request->post('old_token', null);
//        $new_token = $request->post('new_token', null);
//
//        return UserFcm::replaceFcm($user->id, $old_token, $new_token);
//    }



}