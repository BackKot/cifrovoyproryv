<?php
namespace api\modules\v1\controllers;


use api\controllers\BaseApiController;
use common\models\HouseType;
use common\models\PersonType;
use common\models\Region;
use common\models\ServiceCategory;
use common\models\ServiceType;
use yii\db\Expression;
use yii\helpers\ArrayHelper;

class DirectoryController extends BaseApiController
{
    public function actionRegions()
    {
        return Region::find()->orderBy('name')->all();
    }

    public function actionHouseTypes()
    {
        return HouseType::find()->orderBy('name')->all();
    }

    public function actionPersonTypes()
    {
        return PersonType::find()->orderBy('name')->all();
    }
}