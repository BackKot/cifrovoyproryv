<?php
$params = array_merge(
    require __DIR__ . '/../../common/config/params.php',
    require __DIR__ . '/../../common/config/params-local.php',
    require __DIR__ . '/params.php',
    require __DIR__ . '/params-local.php'
);

return [
    'id' => 'app-api',
    'basePath' => dirname(__DIR__),
    'controllerNamespace' => 'api\controllers',
    'modules' => [
        'v1' => [
            'class' => 'api\modules\v1\Module',
        ],
//        'v2' => [
//            'class' => 'app\modules\v2\Module',
//        ],
    ],
    'components' => [
        'urlManager' => [
            'enablePrettyUrl' => true,
//            'enableStrictParsing' => true,
            'showScriptName' => false,
            'rules' => require(__DIR__ . '/routes.php'),
//            'rules' => [
////                ['class' => 'yii\rest\UrlRule', 'controller' => 'user'],
////                ['class' => 'yii\rest\UrlRule', 'controller' => ['v1/login']],
////                ['class' => 'yii\rest\UrlRule', 'controller' => ['v2/user', 'v2/post']],
//            ],
        ],
        'user' => [
            'identityClass' => 'common\models\User',
            'enableSession' => false
        ],

        'request' => [
            'parsers' => [
                'application/json' => 'yii\web\JsonParser',
            ]
        ],

        'response' => [
            'class' => 'yii\web\Response',
            'format' => yii\web\Response::FORMAT_JSON,
            'formatters' => [
                \yii\web\Response::FORMAT_JSON => [
                    'class' => 'yii\web\JsonResponseFormatter',
                    'prettyPrint' => YII_DEBUG, // use "pretty" output in debug mode
                    'encodeOptions' => JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE,
                ],
            ],
            //'charset' => 'UTF-8'
            'on beforeSend' => function ($event) {
                api\controllers\BaseApiController::responseBeforeSend($event);
            },
        ],

    ],


    'params' => $params,
];
