<?php
namespace console\controllers;

use common\models\User;
use paragraph1\phpFCM\Recipient\Device;
use Yii;
use yii\console\Controller;
use yii\console\ExitCode;
use yii\helpers\ArrayHelper;
use yii\helpers\Console;

class UserController extends Controller
{

    public function actionIndex()
    {
        $this->stdout("Supported commands:\n", Console::BOLD);
        echo 'user/create email password';
        return ExitCode::OK;
    }

    public function actionCreate($email, $password)
    {
        $validator = new \yii\validators\EmailValidator();

        if (!$validator->validate($email, $error)) {
            $this->stderr($error, Console::FG_RED);
            return ExitCode::UNSPECIFIED_ERROR;
        }

        if (strlen($password) < 3) {
            $this->stderr(Yii::t('app', 'Password too short').PHP_EOL, Console::FG_RED);
            return ExitCode::UNSPECIFIED_ERROR;
        }

        if (User::findOne(['email' => $email])) {
            $this->stderr(Yii::t('app', 'User email {0} already registered', $email).PHP_EOL, Console::FG_RED);
            return ExitCode::UNSPECIFIED_ERROR;
        }

        $user = new User();
        $user->username = $email;
        $user->email = $email;
        $user->status = User::STATUS_ACTIVE;
        $user->setPassword($password);
        $user->generateAuthKey();
        $user->generateAccessToken();
        if ($user->save()) {
            $this->stdout(Yii::t('app', 'User created').PHP_EOL, Console::FG_GREEN);
        } else {
            $error_text = '';
            foreach ($user->firstErrors as $attr => $error) {
                $error_text = "$attr => $error\n";
            }

            $this->stderr(Yii::t('app', 'User email {0} already registered', $error_text).PHP_EOL, Console::FG_RED);
            return ExitCode::UNSPECIFIED_ERROR;
        }
    }

    public function actionTestNotification($user_id)
    {
        $user = User::findOne($user_id);
        if (!$user) {
            $this->stderr(Yii::t('app', 'User with id = {0} not found', $user_id).PHP_EOL, Console::FG_RED);
            return ExitCode::UNSPECIFIED_ERROR;
        }


        $note = Yii::$app->fcm->createNotification("Test title", "Testing body");
        $note->setIcon('notification_icon_resource_name')
            ->setColor('#ffffff')
            ->setBadge(1);

        $message = Yii::$app->fcm->createMessage();
        $message->addRecipient(new Device('your-device-token'));
        $message->setNotification($note)
            ->setData(['someId' => 111]);

        $response = Yii::$app->fcm->send($message);
        var_dump($response->getStatusCode());
    }
}