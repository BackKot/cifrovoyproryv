<?php

use yii\db\Migration;

/**
 * Class m190516_162734_add_user_access_token
 */
class m190516_162734_add_user_access_token extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        //https://developpaper.com/yii-2-0-restful-api-authentication-tutorial-token-verification/
        $this->addColumn('user', 'access_token', $this->string(64));
        foreach (\common\models\User::find()->all() as $user) {
            $user->generateAccessToken();
            $user->save(false);
        }
        $this->alterColumn('user', 'access_token',  'DROP NOT NULL');
        $this->createIndex('udx_user_access_token', 'user', 'access_token', true);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropColumn('user', 'access_token');
    }

}
