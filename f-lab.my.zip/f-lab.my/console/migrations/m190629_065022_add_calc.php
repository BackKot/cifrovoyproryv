<?php

use yii\db\Migration;

/**
 * Class m190629_065022_add_calc
 */
class m190629_065022_add_calc extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        // person_type
        $this->createTable('person_type',[
            'id' => $this->primaryKey(),
            'name' => $this->string(255)->notNull(),
        ]);

        $this->batchInsert('person_type',['name'],[
            ['Одиноко проживающий гражданин'],
            ['Гражданин проживающий в общежитии'],
            ['Одиноко проживающий пенсионер'],
            ['Гражданин в составе семьи'],
            ['Семья из 2х пенсионеров'],
        ]);

        // house_type
        $this->createTable('house_type',[
            'id' => $this->primaryKey(),
            'name' => $this->string(255)->notNull(),
        ]);

        $this->batchInsert('house_type',['name'],[
            ['Многоквартиный дом'],
            ['Жилой дом']
        ]);

        // period_type
        $this->createTable('period_type',[
            'id' => $this->primaryKey(),
            'name' => $this->string(255)->notNull(),
        ]);

        $this->batchInsert('period_type',['name'],[
            ['Отопительный'],
            ['Межотопительный']
        ]);



    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('person_type');
        $this->dropTable('house_type');
        $this->dropTable('period_type');
    }
}
