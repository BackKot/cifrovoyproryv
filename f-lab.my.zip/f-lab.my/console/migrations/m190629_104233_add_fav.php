<?php

use yii\db\Migration;

/**
 * Class m190629_104233_add_fav
 */
class m190629_104233_add_fav extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('user_fav',[
            'id' => $this->primaryKey(),
            'user_id' => $this->integer()->notNull(),
            'created_at' => 'timestamp with time zone not null',
            'data' => 'jsonb'
        ]);

        $this->addForeignKey("fk_user_fav_user", 'user_fav', "user_id", "user", "id", "RESTRICT", "RESTRICT");
        $this->createIndex('idx_user_fav_user_id', 'user_fav', 'user_id');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('user_fav');
    }

}
