<?php

use yii\db\Migration;

/**
 * Class m190629_101626_user_profile
 */
class m190629_101626_user_profile extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        // person_type
        $this->createTable('user_profile',[
            'id' => $this->primaryKey(),
            'user_id' => $this->integer()->notNull(),
            'first_name' => $this->string(255),
            'second_name' => $this->string(255),
            'third_name' => $this->string(255),
            'snils' => $this->string(255),
            'pasp_num' => $this->string(255),
            'pasp_ser' => $this->string(255),
            'pasp_date' => $this->date(),
            'inn' => $this->string(255),
        ]);

        $this->createIndex('udx_user_profile_user_id', 'user_profile', 'user_id', true);
        $this->addForeignKey("fk_user_profile_user", 'user_profile', "user_id", "user", "id", "RESTRICT", "RESTRICT");
        $this->createIndex('idx_user_profile_user_id', 'user_profile', 'user_id');

    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('user_profile');
    }
}
