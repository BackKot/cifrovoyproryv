<?php
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'pgsql:host=85.17.248.64;dbname=soccalc',
            'username' => 'postgres',
            'password' => 'super_pass',
//            'dsn' => 'pgsql:host=localhost;dbname=f_lab_db_2',
//            'username' => 'postgres',
//            'password' => 'root',
            'charset' => 'utf8',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@common/mail',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => true,
        ],
    ],
    'timeZone' => 'Asia/Krasnoyarsk',
];
